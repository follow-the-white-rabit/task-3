package com.company;

public class WhiteHouseDecorator extends HouseDecorator{

    public WhiteHouseDecorator(House house){
        super(house);

        System.out.println("Coloring this house to white...");
    }

    @Override
    public String  build() {
        return house.build() + ", Color: White";
    }
}
