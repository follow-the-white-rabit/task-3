package com.company;

public class BigWindowsDecorator extends HouseDecorator{

    public BigWindowsDecorator(House house){
        super(house);

        System.out.println("Setting up to this house big windows...");
    }

    @Override
    public String  build() {
        return house.build() + ", Windows: 4 Big";
    }
}
