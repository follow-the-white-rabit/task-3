package com.company;

public class Main {

    public static void main(String[] args) {
        House house = new BigWindowsDecorator(new WhiteHouseDecorator(new StoneHouse()));

        System.out.println("House description:  " + house.build());
    }
}
