package com.company;

public class WoodHouse implements House{
    @Override
    public String build() {
        return "We build wood house.";
    }
}
