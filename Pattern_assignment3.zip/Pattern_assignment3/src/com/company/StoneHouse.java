package com.company;

public class StoneHouse implements House{
    @Override
    public String build() {
        return "We build stone house.";
    }
}
