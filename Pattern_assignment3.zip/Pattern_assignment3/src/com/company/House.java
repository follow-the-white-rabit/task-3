package com.company;

public interface House {
    String build();
}
