package com.company;

public class HouseDecorator implements House{
    House house;

    public HouseDecorator(House house) {
        this.house = house;
    }

    @Override
    public String build() {
        return house.build();
    }
}
